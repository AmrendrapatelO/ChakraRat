import tkinter as tk
from server import broadcast

# Simple GUI for RAT control
def send_command():
    command = command_entry.get()
    broadcast(command)

root = tk.Tk()
root.title("RAT Command Center")

command_label = tk.Label(root, text="Enter Command:")
command_label.pack()

command_entry = tk.Entry(root, width=50)
command_entry.pack()

send_button = tk.Button(root, text="Send Command", command=send_command)
send_button.pack()

root.mainloop()